'use strict';

const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const db = require('../config/database');
const config = require('../config/env');
const portfolioService = require('./portfolioService');
const reviewService = require('./reviewService');
const backupService = require('./backupService');
const notificationService = require('./notificationService');
const { todayString, addDays, isWeekend, dateTimeLabel } = require('../utils/date');
const { createLogger } = require('../utils/logger');
const jobService = require('./jobService');

const log = createLogger('scheduler');

class FundScheduler {
  constructor() {
    this.tasks = [];
    this.locks = new Set();
    this.started = false;
  }

  start() {
    if (this.started) return;
    this._seedHolidays();

    const tz = { timezone: config.timezone };

    this._add('18:00 收盘后拉取', '0 18 * * 1-5', () => this.runSync('evening'));
    this._add('20:00 净值复核', '0 20 * * 1-5', () => this.runSync('night-early'));
    this._add('22:00 净值兜底', '0 22 * * 1-5', () => this.runSync('night-late'));
    this._add('22:30 每日复盘', '30 22 * * 1-5', () => this.runDailyReview());
    this._add('周日 20:00 周度复盘', '0 20 * * 0', () => this.runWeeklyReview());
    this._add('月末 20:30 月度复盘', '30 20 28-31 * *', () => this.runMonthlyReviewIfLastDay());
    this._add('23:10 数据库备份', '10 23 * * *', () => this.runBackup());

    this.started = true;
    log.info(`定时任务已启动（时区 ${config.timezone}）：18:00 / 20:00 / 22:00 拉净值，22:30 复盘，周日周复盘，月末月复盘，23:10 备份`);

    this._startupCatchUp();
  }

  stop() {
    this.tasks.forEach((task) => task.stop());
    this.tasks = [];
    this.started = false;
  }

  _add(label, expression, handler, options = {}) {
    if (!cron.validate(expression)) {
      log.error(`cron 表达式无效: ${expression}`);
      return;
    }
    const task = cron.schedule(expression, () => {
      Promise.resolve(handler()).catch((error) => log.error(`${label} 执行失败: ${error.message}`));
    }, { timezone: config.timezone, ...options });
    this.tasks.push({ label, task });
  }

  /** 节假日表：来自 config/market-holidays.json，可手工追加 */
  _seedHolidays() {
    const file = path.join(__dirname, '../config/market-holidays.json');
    if (!fs.existsSync(file)) return;
    try {
      const json = JSON.parse(fs.readFileSync(file, 'utf8'));
      let inserted = 0;
      for (const [year, ranges] of Object.entries(json.years || {})) {
        if (!Array.isArray(ranges)) continue;
        for (const range of ranges) {
          let cursor = range.from;
          while (cursor && cursor <= range.to) {
            const exists = db.get('SELECT date FROM trading_holidays WHERE date = ?', [cursor]);
            if (!exists) {
              db.run('INSERT OR IGNORE INTO trading_holidays (date, name) VALUES (?, ?)', [cursor, `${range.name} ${year}`]);
              inserted += 1;
            }
            cursor = addDays(cursor, 1);
          }
        }
      }
      if (inserted) log.info(`交易日历已更新：新增 ${inserted} 个休市日`);
    } catch (error) {
      log.warn(`交易日历读取失败: ${error.message}`);
    }
  }

  isTradingDay(date = todayString()) {
    if (isWeekend(date)) return false;
    return !db.get('SELECT date FROM trading_holidays WHERE date = ?', [date]);
  }

  async _exclusive(name, fn) {
    if (this.locks.has(name)) {
      log.info(`${name} 正在执行中，本次跳过`);
      return { status: 'skipped', reason: 'running' };
    }
    this.locks.add(name);
    try {
      return await fn();
    } finally {
      this.locks.delete(name);
    }
  }

  async runSync(reason) {
    if (!this.isTradingDay()) {
      log.info(`${todayString()} 非交易日，跳过净值同步`);
      return { status: 'skipped', reason: 'holiday' };
    }
    return this._exclusive('sync', async () => {
      const result = await portfolioService.syncAll(reason);
      await this._notifyCritical();
      return result;
    });
  }

  async _notifyCritical() {
    const alerts = portfolioService.listAlerts(10, { unreadOnly: true });
    const critical = alerts.filter((a) => a.level === 'critical');
    if (!critical.length) return;
    await notificationService.send({
      title: `基金提醒：${critical[0].title}`,
      message: critical.map((a) => `- ${a.title}\n  ${a.message || ''}`).join('\n'),
      level: 'critical',
    });
    // 已推送过的关键提醒标记已读，避免下次重复推送
    portfolioService.markAlertsRead(critical.map((a) => a.id));
  }

  async runDailyReview() {
    if (!this.isTradingDay()) {
      log.info('非交易日，跳过每日复盘');
      return { status: 'skipped' };
    }
    return this._exclusive('review', () => reviewService.generateDaily());
  }

  async runWeeklyReview() {
    return this._exclusive('review', () => reviewService.generate('weekly'));
  }

  async runMonthlyReviewIfLastDay() {
    const tomorrow = addDays(todayString(), 1);
    if (tomorrow.slice(8, 10) !== '01') return { status: 'skipped' };
    return this._exclusive('review', () => reviewService.generate('monthly'));
  }

  async runBackup() {
    if (!config.backupEnabled) return { status: 'skipped' };
    try {
      const result = backupService.backupDatabase();
      const job = jobService.start('backup');
      jobService.finish(job, 'success', result);
      return result;
    } catch (error) {
      log.error(`自动备份失败: ${error.message}`);
      const job = jobService.start('backup');
      jobService.finish(job, 'failed', null, error.message);
      return { status: 'failed', message: error.message };
    }
  }

  /**
   * 启动补跑：如果服务在收盘后启动、当天的净值还没入库，自动补一次。
   * 避免"晚上才开机就一整天没数据"。
   */
  _startupCatchUp() {
    const now = new Date();
    const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: config.timezone, hour: '2-digit', hour12: false }).format(now));
    if (!this.isTradingDay() || hour < 18) return;

    const holdings = db.get('SELECT COUNT(*) AS n FROM holdings').n;
    if (!holdings) return;

    const yesterday = addDays(todayString(), -1);
    const latest = db.get('SELECT MAX(last_net_date) AS d FROM funds WHERE last_net_date >= ?', [yesterday]).d;
    if (latest && latest >= todayString()) return;

    log.info('检测到今日净值尚未入库，60 秒后自动补跑一次同步');
    setTimeout(() => {
      this.runSync('startup-catchup').catch((error) => log.error(`补跑失败: ${error.message}`));
    }, 60 * 1000).unref?.();
  }
}

module.exports = new FundScheduler();

# 手机随时看（不买服务器）

目标：电脑开着，手机在同一个 Wi-Fi、或者在外面，都能打开这个基金助手。

## 一、同一个 Wi-Fi（最简单，先用这个）

1. 电脑上启动服务：`npm start`，看到监听 `0.0.0.0:3000`。
2. 页面「手机随时看」会直接写出地址，例如 `http://192.168.28.157:3000`。
3. 手机连同一个 Wi-Fi，浏览器输入这个地址。
4. 加到桌面：
   - iPhone Safari：分享 → 添加到主屏幕。
   - 安卓 Chrome / Edge：右上角菜单 → 添加到主屏幕 / 安装应用。
5. 打不开时，先在电脑放行防火墙：

```powershell
New-NetFirewallRule -DisplayName "Fund Assistant 3000" -Direction Inbound -Protocol TCP -LocalPort 3000 -Action Allow -Profile Private
```

只用私有网络配置，不要把 3000 端口映射到公网。

## 二、在外网（免费 Tailscale，推荐）

Tailscale 是点对点私有网络：电脑和手机都装客户端、登同一个账号，手机就能用 `100.x.x.x` 访问电脑，不需要公网 IP、不需要买服务器、也不需要端口映射。

1. 电脑安装 Tailscale（Windows 版），登录账号。
2. 手机安装 Tailscale（iOS / Android），登录**同一个账号**。
3. 电脑查自己的 Tailscale 地址：

```powershell
tailscale ip -4
```

会得到一个 `100.x.x.x`。

4. 手机浏览器打开：

```text
http://100.x.x.x:3000
```

5. 同样可以“添加到主屏幕”，以后点开就用。

注意：

- 电脑必须开机、服务必须在跑；电脑睡眠会断。
- 不要开“Exit node”之类的高级功能，普通同账号组网就够。
- Tailscale 免费版个人使用足够（设备数量有限制，两三台没问题）。

## 三、备选：Cloudflare 临时隧道

不想装 Tailscale，可以临时用 Cloudflare 快速隧道：

```powershell
cloudflared tunnel --url http://localhost:3000
```

它会输出一个 `https://xxxx.trycloudflare.com` 的临时地址，手机直接打开。缺点是**每次重启地址都会变**，而且流量经过第三方，适合临时看一眼，不适合长期。

## 四、安全边界

- 这个服务没有登录系统，默认只给自己用。**不要做路由器端口映射**，不要把 3000 暴露到公网。
- 想加一道口令：`.env` 里设置 `API_TOKEN=你的口令`，页面首次打开会要求输入。
- 数据库和 Key 都在本机 `fund.db`，Tailscale 只是把本机页面私密地转给手机，不经过云端存储。
- 电脑关机 / 服务停止，手机就打不开——这是“不买服务器”的唯一代价。

## 五、常见问题

| 现象 | 处理 |
| --- | --- |
| 手机同一个 Wi-Fi 打不开 | 确认地址是 `192.168.x.x` 而不是 `127.0.0.1`；放行防火墙；确认电脑和手机在同一网段 |
| 外网 100.x 打不开 | 两端 Tailscale 都要在线；电脑服务在跑；地址带 `:3000` |
| 页面能开但数据不刷新 | 净值本来每晚才更新；盘中只有估值，非交易时段为空 |
| 添加到桌面没有图标 | 用 Chrome / Edge / Safari；国产浏览器可能不支持 PWA 安装 |

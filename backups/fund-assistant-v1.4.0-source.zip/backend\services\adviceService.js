'use strict';

const db = require('../config/database');
const config = require('../config/env');
const fundDataService = require('./fundDataService');
const marketService = require('./marketService');
const { computeStats, decide, inferStrategy, buildPlan } = require('../domain/advice');
const { mapWithConcurrency } = require('../utils/asyncPool');
const { createLogger } = require('../utils/logger');

const log = createLogger('advice');

const HISTORY_DAYS = 90;

/**
 * 把"持仓 + 净值历史 + 大盘"翻译成可执行建议。
 * 单笔建议挂在 position.advice 上，组合结论挂在 portfolio.advice.plan 上。
 */
async function buildAdvice({ positions, summary, today }) {
  if (!positions || positions.length === 0) {
    return {
      plan: buildPlan({ positions: [], summary, market: {} }),
      items: [],
      market: await safeMarket([], {}),
    };
  }

  const codes = [...new Set(positions.map((p) => p.code))];
  const histories = new Map();
  await mapWithConcurrency(codes.map((code) => ({ code })), Math.min(config.fetchConcurrency, 3), async ({ code }) => {
    try {
      histories.set(code, await fundDataService.getHistory(code, HISTORY_DAYS));
    } catch (error) {
      histories.set(code, []);
      log.warn(`${code} 历史净值获取失败: ${error.message}`);
    }
  });

  const market = await safeMarket(codes, { today });
  const items = positions.map((position) => {
    const rows = histories.get(position.code) || [];
    const stats = computeStats(rows, { buyDate: position.buyDate });
    const stored = String(position.strategy || 'auto');
    const inferred = inferStrategy({ type: position.fundType, name: position.name, volatility: stats.volatility });
    const strategy = stored === 'long' || stored === 'swing' ? stored : inferred.strategy;
    const strategyReason = stored === 'long' || stored === 'swing'
      ? '按你设定的策略判断'
      : inferred.reason;

    const advice = decide({ position, stats, strategy, strategyReason, today });
    const estimate = market.estimates?.[position.code] || null;

    return {
      id: position.id,
      code: position.code,
      name: position.name,
      realPct: Number((position.profit?.realRate || 0) * 100),
      estimate: estimate && estimate.estimateNav
        ? { nav: estimate.estimateNav, pct: estimate.estimatePct, time: estimate.estimateTime }
        : null,
      ...advice,
    };
  });

  const plan = buildPlan({ positions, summary, market, adviceList: items });
  return { plan, items, market, statsByCode: Object.fromEntries(items.map((item) => [item.code, item.stats])) };
}

async function safeMarket(codes, options) {
  try {
    return await marketService.getSnapshot(codes, options);
  } catch (error) {
    log.warn(`行情快照失败: ${error.message}`);
    return { indices: [], estimates: {}, state: 'unknown', stateLabel: '行情不可用', asOf: null };
  }
}

/** 给复盘正文引用的"今日建议"摘要 */
function planLines(advice) {
  if (!advice || !advice.plan) return [];
  const lines = [`结论：${advice.plan.headline}`];
  if (advice.plan.subline) lines.push(`说明：${advice.plan.subline}`);
  for (const action of advice.plan.actions) {
    lines.push(`${action.name}（${action.code}）：${action.verdictLabel} —— ${action.action}`);
  }
  for (const flag of advice.plan.flags) {
    lines.push(`提示：${flag.title} —— ${flag.text}`);
  }
  return lines;
}

function holdingsWithStrategy() {
  return db.all('SELECT id, fund_code, strategy FROM holdings');
}

module.exports = { buildAdvice, planLines, holdingsWithStrategy };

'use strict';

const aiClient = require('./aiClient');
const aiConfigService = require('./aiConfigService');
const portfolioService = require('./portfolioService');
const fundCheckService = require('./fundCheckService');
const { createLogger } = require('../utils/logger');

const log = createLogger('assistant');

const CHIPS = ['110022 能不能买', '现在该卖吗', '我的仓位有问题吗', '赎回费怎么算'];
const CODE_RE = /(\d{6})/;
const BUY_RE = /(买|买入|加仓|上车|适合|能不能|值不值|体检|靠谱|机会)/;
const SELL_RE = /(卖|卖出|抛|减仓|止盈|止损|清仓|割肉|跑)/;
const POSITION_RE = /(仓位|组合|集中|分散|风险|配置|占比)/;
const MARKET_RE = /(大盘|行情|指数|开盘|收盘|上证|深证|创业板|涨|跌)/;
const FEE_RE = /(费率|手续费|赎回费|申购费|管理费|托管费)/;
const HELP_RE = /(怎么用|能做什么|功能|帮助|你会|你是谁)/;

function extractCode(text) {
  const match = String(text || '').match(CODE_RE);
  return match ? match[1] : null;
}

function pctText(ratio) {
  return `${(Number(ratio) * 100).toFixed(2)}%`;
}

function signedPct(ratio) {
  const value = Number(ratio) * 100;
  return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
}

function joinLines(lines) {
  return lines.filter((line) => line !== null && line !== undefined && line !== '').join('\n');
}

function marketLine(market) {
  if (!market || !Array.isArray(market.indices) || !market.indices.length) {
    return '现在拿不到指数行情（不影响净值和建议）';
  }
  return market.indices
    .map((item) => `${item.name} ${Number(item.price).toFixed(2)}（${signedPct(item.pct)}）`)
    .join('，');
}

function sellAnswer(portfolio) {
  const positions = portfolio?.positions || [];
  if (!positions.length) {
    return {
      title: '卖出判断',
      answer: '你还没有持仓，暂时没有可卖的。先在「添加持仓」里录入，我才能按纪律线判断。',
      chips: CHIPS,
    };
  }
  const items = positions.filter((pos) => pos.advice);
  const needAction = items.filter((pos) => Number(pos.advice.urgency) >= 1);
  const lines = [
    needAction.length
      ? `今天有 ${needAction.length} 笔需要处理：`
      : `今天 ${items.length} 笔都不用动手，都在纪律线内：`,
  ];
  for (const pos of items) {
    lines.push(`· ${pos.name}：${pos.advice.verdictLabel} —— ${pos.advice.action}`);
    const triggers = (pos.advice.triggers || []).slice(0, 2).map((t) => `${t.label} ${t.value}`);
    if (triggers.length) lines.push(`  盯：${triggers.join(' / ')}`);
  }
  lines.push('判断依据是趋势、回撤、赎回费和你的止盈止损线，不预测涨跌。');
  return { title: '卖出判断', answer: joinLines(lines), chips: CHIPS };
}

function positionAnswer(portfolio) {
  const summary = portfolio?.summary || {};
  const plan = portfolio?.advice?.plan;
  if (!portfolio?.positions?.length) {
    return {
      title: '组合检查',
      answer: '你还没有持仓。先加一两笔试水，我就能帮你盯集中度和整体风险。',
      chips: CHIPS,
    };
  }
  const lines = [
    `当前 ${summary.fundCount || 0} 笔、市值 ${Number(summary.value || 0).toFixed(2)} 元，单笔最大占比 ${pctText(summary.topWeight || 0)}。`,
  ];
  if (plan?.flags?.length) {
    for (const flag of plan.flags) lines.push(`· ${flag.title}：${flag.text}`);
  } else {
    lines.push('· 组合层面暂时没有触发集中度、系统性下跌或整体浮亏的提醒。');
  }
  lines.push(`今日结论：${plan?.headline || '—'}`);
  lines.push('集中度只看占比，不代表好坏；但只押一只基金时，它的波动就是你的全部波动。');
  return { title: '组合检查', answer: joinLines(lines), chips: CHIPS };
}

function marketAnswer(market) {
  const state = market?.stateLabel || '行情状态未知';
  const lines = [
    `现在是${state}。${marketLine(market)}`,
    '交易时段每 30 秒刷新指数；盘中估值来自东财 GSZ 字段，没有估值时卡片只显示最新净值。',
    '指数只用来判断"今天是不是系统性下跌"，不构成买卖信号。',
  ];
  return { title: '大盘情况', answer: joinLines(lines), chips: CHIPS };
}

function feeAnswer(portfolio) {
  const positions = portfolio?.positions || [];
  if (!positions.length) {
    return {
      title: '费率说明',
      answer: '场外基金通常：申购费按金额分档（天天基金常打 1 折，约 0.15%）；赎回费按持有天数递减，7 天内一般 1.5%，7 天到一年约 0.5%，两年以上常为 0。管理费和托管费每天从基金资产里扣，已经含在净值里，不要重复扣。',
      chips: CHIPS,
    };
  }
  const lines = ['你这几笔现在的赎回费和"再等几天更划算"：'];
  for (const pos of positions) {
    const fees = pos.profit?.fees || {};
    const opt = pos.profit?.redemption?.optimization;
    lines.push(`· ${pos.name}：持有 ${pos.profit?.holdDays ?? '—'} 天，赎回费 ${pctText(fees.redemptionRate || 0)}${opt?.text ? `；${opt.text}` : ''}`);
  }
  lines.push('管理费、托管费已包含在公布净值里，程序不会重复扣。');
  return { title: '费率说明', answer: joinLines(lines), chips: CHIPS };
}

function helpAnswer() {
  return {
    title: '我能做什么',
    answer: joinLines([
      '我只会用你自己的持仓数据和纪律线回答问题，不预测涨跌：',
      '· 买之前体检：发 6 位代码，例如「110022 能不能买」，我给纪律分、买多少、跌破多少走',
      '· 卖不卖：问「现在该卖吗」，我按止损/止盈/趋势/费率逐笔给结论',
      '· 组合风险：问「我的仓位有问题吗」，看集中度和整体浮亏',
      '· 大盘：问「今天大盘怎么样」，看指数和交易状态',
      '· 费率：问「赎回费怎么算」，看每笔的费档和等待是否划算',
    ]),
    chips: CHIPS,
  };
}

/**
 * 规则回答：不联网也能用，所有数字都来自当前快照。
 */
function buildRuleAnswer({ question, code, portfolio, market, check }) {
  const text = String(question || '').trim();
  const marketData = market || portfolio?.market || null;
  const wantBuy = BUY_RE.test(text);
  const hasCode = Boolean(code || extractCode(text));

  if (check) {
    return {
      intent: 'check',
      title: `${check.name} 体检`,
      answer: [
        `${check.gradeLabel}，纪律分 ${check.score === null ? '—' : check.score}/100。`,
        check.headline,
        '具体的判断依据、风险和执行线在下面的体检卡里；以上是规则判断，不预测涨跌。',
      ].join('\n'),
      check,
      chips: CHIPS,
    };
  }

  if (wantBuy && !hasCode) {
    return {
      intent: 'ask-code',
      title: '买之前先体检',
      answer: joinLines([
        '买之前我可以先给你体检：把 6 位基金代码发我，例如「110022 能不能买」。',
        '我会看它的趋势、回撤位置、年化波动、申购赎回费，再结合你现在的组合集中度，给出"能不能买、先买多少、跌破多少走"。',
        '没有代码我不会瞎猜——盲目买才是真的可能亏钱。',
      ]),
      chips: CHIPS,
    };
  }

  if (SELL_RE.test(text)) {
    return { intent: 'sell', ...sellAnswer(portfolio) };
  }
  if (POSITION_RE.test(text)) {
    return { intent: 'position', ...positionAnswer(portfolio) };
  }
  if (MARKET_RE.test(text)) {
    return { intent: 'market', ...marketAnswer(marketData) };
  }
  if (FEE_RE.test(text)) {
    return { intent: 'fee', ...feeAnswer(portfolio) };
  }
  if (HELP_RE.test(text)) {
    return { intent: 'help', ...helpAnswer() };
  }

  return {
    intent: 'fallback',
    title: '可以这样问我',
    answer: joinLines([
      '我没听懂具体要判断哪件事。你可以直接问：',
      '· 「110022 能不能买」——买入体检',
      '· 「现在该卖吗」——逐笔卖出结论',
      '· 「我的仓位有问题吗」——集中度和组合风险',
      '· 「今天大盘怎么样」——指数和交易状态',
    ]),
    chips: CHIPS,
  };
}

function compactSnapshot(portfolio, market, check) {
  const positions = (portfolio?.positions || []).map((pos) => ({
    code: pos.code,
    name: pos.name,
    strategy: pos.advice?.strategyLabel,
    verdict: pos.advice?.verdictLabel,
    action: pos.advice?.action,
    realPct: pos.profit?.realRate ? Number((pos.profit.realRate * 100).toFixed(2)) : null,
    holdDays: pos.profit?.holdDays,
    triggers: pos.advice?.triggers?.map((t) => `${t.label} ${t.value}`),
  }));
  return {
    today: portfolio?.meta?.today || null,
    summary: portfolio?.summary || null,
    plan: portfolio?.advice?.plan || null,
    positions,
    market: market ? { state: market.stateLabel, indices: (market.indices || []).map((i) => `${i.name} ${i.price} ${i.pct}%`) } : null,
    check: check ? { name: check.name, score: check.score, grade: check.gradeLabel, reasons: check.reasons, risks: check.risks, plan: check.plan } : null,
  };
}

async function askAI({ question, snapshot, ruleAnswer }) {
  const system = [
    '你是用户个人基金助手的问答模块，用户是投资小白。',
    '只能依据下面 JSON 里的数据回答，不能编造净值、费率、收益。',
    '不预测涨跌，不给"必涨/抄底"结论；只讲纪律：止损线、止盈线、仓位、费率、趋势。',
    '回答用简体中文，先给结论，再给 2-4 条理由，最后一句风险提示，总字数不超过 350 字。',
    '如果数据不足以回答，直接说缺什么，不要猜。',
    `数据：${JSON.stringify(snapshot)}`,
    `规则引擎的参考结论（可改写得更口语，但数字必须一致）：${ruleAnswer.answer}`,
  ].join('\n');

  const result = await aiClient.chat({
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: String(question).slice(0, 500) },
    ],
    temperature: 0.3,
    maxTokens: 700,
  });
  return result.content;
}

async function ask({ question, code }) {
  const text = String(question || '').trim();
  if (!text) {
    return { mode: 'rule', ...helpAnswer() };
  }

  const wantCode = extractCode(text) || (code ? String(code) : null);
  let portfolio = null;
  try {
    portfolio = await portfolioService.buildPortfolio({});
  } catch (error) {
    log.warn(`组合数据获取失败: ${error.message}`);
  }

  let check = null;
  if (wantCode && BUY_RE.test(text)) {
    try {
      check = await fundCheckService.checkFundByCode(wantCode);
    } catch (error) {
      log.warn(`${wantCode} 体检失败: ${error.message}`);
    }
  }

  const market = portfolio?.market || null;
  const ruleAnswer = buildRuleAnswer({ question: text, code: wantCode, portfolio, market, check });

  const aiReady = aiConfigService.isReady();
  if (!aiReady) {
    return { mode: 'rule', ...ruleAnswer, aiReady: false };
  }

  try {
    const answer = await askAI({ question: text, snapshot: compactSnapshot(portfolio, market, check), ruleAnswer });
    return { mode: 'ai', ...ruleAnswer, answer, aiReady: true };
  } catch (error) {
    log.warn(`AI 调用失败，回退规则回答: ${error.message}`);
    return { mode: 'rule', ...ruleAnswer, aiReady: true, aiError: error.message };
  }
}

module.exports = { ask, buildRuleAnswer, extractCode, CHIPS };
